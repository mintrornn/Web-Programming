/* Model: Connect to the Course JSON */
const courseJSON = require('../resources/data/course.json');
module.exports.courseJSON = courseJSON;
/* -------------------------- */
