const express = require('express');
const course = express.Router()
// Use this code if you want to use JSON
const courseList = require('../models/reminder-model').courseJSON;
course.get('/', function (req, res) {
    console.log("From JSON");
    res.render(' course', { 'courses': courseList });
})
// Use this code if you want to connect with DB
const CourseMng = require('../models/reminder-model').CourseMng;
const courseMng = new CourseMng();
course.get('/', async function (req, res) {
    console.log("From DB");
    const results = await courseMng.getAllCourses();
    res.render(' homepage', { 'data': results });
})
module.exports = course;